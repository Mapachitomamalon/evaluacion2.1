document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("formAuto");
  const colorSelect = document.getElementById("colorAuto");
  const imgAuto = document.getElementById("imagenAuto");
  const resultado = document.getElementById("resultado");

  const adicionalesValores = {
    neblineros: 80000,
    portaequipaje: 350000,
    mascotas: 50000,
    led: 70000,
    camara: 100000
  };

  const colorPrecios = {
    blanco: 0,
    negro: 800000,
    rojo: 400000
  };

  const colorImagenes = {
    blanco: "img/blanco.jpg",
    negro: "img/negro.jpg",
    rojo: "img/rojo.png"
  };

  colorSelect.addEventListener("change", () => {
    const color = colorSelect.value;
    imgAuto.src = colorImagenes[color];
  });

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const color = colorSelect.value;
    const base = 3500000;
    const recargo = colorPrecios[color];

    const seleccionados = [];
    let totalAdicionales = 0;

    for (let key in adicionalesValores) {
      const check = document.getElementById(key);
      if (check.checked) {
        seleccionados.push(`${key} ($${adicionalesValores[key].toLocaleString()})`);
        totalAdicionales += adicionalesValores[key];
      }
    }

    const total = base + recargo + totalAdicionales;

    resultado.innerHTML = `
      <h4>Resumen de la compra</h4>
      <p><strong>Color seleccionado:</strong> ${color.charAt(0).toUpperCase() + color.slice(1)}</p>
      <p><strong>Adicionales:</strong> ${seleccionados.length ? seleccionados.join(", ") : "Ninguno"}</p>
      <p><strong>Valor final:</strong> $${total.toLocaleString()}</p>
    `;
  });
});
